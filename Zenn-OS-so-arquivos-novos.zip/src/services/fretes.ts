// Tabelas "Frete NFS" (fretes de chapa).
// Com Supabase ativo grava nas tabelas frete_tabelas / frete_linhas;
// no modo demo grava no navegador (localStorage).

import { getSupabase } from '@/lib/supabase'
import { useSupabaseProvider } from '@/lib/env'
import { uid } from '@/utils/id'

export interface FreteTabela {
  id: string
  titulo: string
  createdAt: string
}

export interface FreteLinha {
  id: string
  tabelaId: string
  ordem: number
  dataEntrega: string | null
  notasFiscais: string | null
  lojaSetor: string | null
  tipoVeiculo: string | null
  placa: string | null
  pesoKg: number | null
  regiao: string | null
  raio: string | null
  valor: number | null
  observacao: string | null
}

export type FreteCampo = Exclude<keyof FreteLinha, 'id' | 'tabelaId' | 'ordem'>

export const LINHAS_INICIAIS = 20

export interface FretesStore {
  listTabelas(): Promise<FreteTabela[]>
  createTabela(titulo: string): Promise<FreteTabela>
  renameTabela(id: string, titulo: string): Promise<void>
  deleteTabela(id: string): Promise<void>
  listLinhas(tabelaId: string): Promise<FreteLinha[]>
  addLinha(tabelaId: string, ordem: number): Promise<FreteLinha>
  updateLinha(id: string, patch: Partial<Pick<FreteLinha, FreteCampo>>): Promise<void>
  deleteLinha(id: string): Promise<void>
}

const COLUNAS: Record<FreteCampo, string> = {
  dataEntrega: 'data_entrega',
  notasFiscais: 'notas_fiscais',
  lojaSetor: 'loja_setor',
  tipoVeiculo: 'tipo_veiculo',
  placa: 'placa',
  pesoKg: 'peso_kg',
  regiao: 'regiao',
  raio: 'raio',
  valor: 'valor',
  observacao: 'observacao',
}

const num = (v: unknown) => (v == null ? null : Number(v))

function linhaFromRow(r: Record<string, unknown>): FreteLinha {
  return {
    id: r.id as string,
    tabelaId: r.tabela_id as string,
    ordem: Number(r.ordem ?? 0),
    dataEntrega: (r.data_entrega as string | null) ?? null,
    notasFiscais: (r.notas_fiscais as string | null) ?? null,
    lojaSetor: (r.loja_setor as string | null) ?? null,
    tipoVeiculo: (r.tipo_veiculo as string | null) ?? null,
    placa: (r.placa as string | null) ?? null,
    pesoKg: num(r.peso_kg),
    regiao: (r.regiao as string | null) ?? null,
    raio: (r.raio as string | null) ?? null,
    valor: num(r.valor),
    observacao: (r.observacao as string | null) ?? null,
  }
}

const linhaVazia = (tabelaId: string, ordem: number): FreteLinha => ({
  id: uid('fl'),
  tabelaId,
  ordem,
  dataEntrega: null,
  notasFiscais: null,
  lojaSetor: null,
  tipoVeiculo: null,
  placa: null,
  pesoKg: null,
  regiao: null,
  raio: null,
  valor: null,
  observacao: null,
})

function db() {
  const client = getSupabase()
  if (!client) throw new Error('Supabase não configurado.')
  return client
}

const supabaseStore: FretesStore = {
  async listTabelas() {
    const { data, error } = await db().from('frete_tabelas').select('*').order('created_at', { ascending: true })
    if (error) throw error
    return (data ?? []).map((r) => ({ id: r.id, titulo: r.titulo, createdAt: r.created_at }))
  },
  async createTabela(titulo) {
    const { data, error } = await db().from('frete_tabelas').insert({ titulo }).select().single()
    if (error) throw error
    const vazias = Array.from({ length: LINHAS_INICIAIS }, (_, ordem) => ({ tabela_id: data.id, ordem }))
    const res = await db().from('frete_linhas').insert(vazias)
    if (res.error) throw res.error
    return { id: data.id, titulo: data.titulo, createdAt: data.created_at }
  },
  async renameTabela(id, titulo) {
    const { error } = await db().from('frete_tabelas').update({ titulo }).eq('id', id)
    if (error) throw error
  },
  async deleteTabela(id) {
    const { error } = await db().from('frete_tabelas').delete().eq('id', id)
    if (error) throw error
  },
  async listLinhas(tabelaId) {
    const { data, error } = await db().from('frete_linhas').select('*').eq('tabela_id', tabelaId).order('ordem', { ascending: true })
    if (error) throw error
    return (data ?? []).map(linhaFromRow)
  },
  async addLinha(tabelaId, ordem) {
    const { data, error } = await db().from('frete_linhas').insert({ tabela_id: tabelaId, ordem }).select().single()
    if (error) throw error
    return linhaFromRow(data)
  },
  async updateLinha(id, patch) {
    const row = Object.fromEntries(Object.entries(patch).map(([k, v]) => [COLUNAS[k as FreteCampo], v]))
    const { error } = await db().from('frete_linhas').update(row).eq('id', id)
    if (error) throw error
  },
  async deleteLinha(id) {
    const { error } = await db().from('frete_linhas').delete().eq('id', id)
    if (error) throw error
  },
}

// ---- modo demo (navegador) ----
const K_TAB = 'zenn-os:fretes:tabelas'
const K_LIN = 'zenn-os:fretes:linhas'
const read = <T,>(key: string): T[] => {
  try {
    return JSON.parse(localStorage.getItem(key) ?? '[]') as T[]
  } catch {
    return []
  }
}
const write = (key: string, value: unknown) => localStorage.setItem(key, JSON.stringify(value))

const localStore: FretesStore = {
  async listTabelas() {
    return read<FreteTabela>(K_TAB)
  },
  async createTabela(titulo) {
    const t: FreteTabela = { id: uid('ft'), titulo, createdAt: new Date().toISOString() }
    write(K_TAB, [...read<FreteTabela>(K_TAB), t])
    write(K_LIN, [...read<FreteLinha>(K_LIN), ...Array.from({ length: LINHAS_INICIAIS }, (_, i) => linhaVazia(t.id, i))])
    return t
  },
  async renameTabela(id, titulo) {
    write(K_TAB, read<FreteTabela>(K_TAB).map((t) => (t.id === id ? { ...t, titulo } : t)))
  },
  async deleteTabela(id) {
    write(K_TAB, read<FreteTabela>(K_TAB).filter((t) => t.id !== id))
    write(K_LIN, read<FreteLinha>(K_LIN).filter((l) => l.tabelaId !== id))
  },
  async listLinhas(tabelaId) {
    return read<FreteLinha>(K_LIN)
      .filter((l) => l.tabelaId === tabelaId)
      .sort((a, b) => a.ordem - b.ordem)
  },
  async addLinha(tabelaId, ordem) {
    const l = linhaVazia(tabelaId, ordem)
    write(K_LIN, [...read<FreteLinha>(K_LIN), l])
    return l
  },
  async updateLinha(id, patch) {
    write(K_LIN, read<FreteLinha>(K_LIN).map((l) => (l.id === id ? { ...l, ...patch } : l)))
  },
  async deleteLinha(id) {
    write(K_LIN, read<FreteLinha>(K_LIN).filter((l) => l.id !== id))
  },
}

export const fretesStore: FretesStore = useSupabaseProvider ? supabaseStore : localStore
